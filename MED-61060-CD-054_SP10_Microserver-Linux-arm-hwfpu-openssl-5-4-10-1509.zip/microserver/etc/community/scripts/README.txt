To include an 3rd party lua scripts
